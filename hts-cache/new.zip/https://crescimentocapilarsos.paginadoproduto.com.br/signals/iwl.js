<html lang="pt-BR">
<!-- begin::Head -->
<head>
    <meta charset="utf-8">
    <title>Clonou</title>
    <meta charset="utf-8">
    <meta name="description" content="Converteu">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="">

    <!--begin::Fonts -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700|Roboto:300,400,500,600,700">        
    <!--end::Fonts -->

    <!--begin::Page Custom Styles(used by this page) -->
    <link href="https://crescimentocapilarsos.paginadoproduto.com.br/css/app.css" rel="stylesheet" type="text/css">
    <link href="https://crescimentocapilarsos.paginadoproduto.com.br/css/error.css" rel="stylesheet" type="text/css">
    <link href="https://crescimentocapilarsos.paginadoproduto.com.br/css/plugins-bundle.css" rel="stylesheet" type="text/css">
    <link href="https://crescimentocapilarsos.paginadoproduto.com.br/css/style-bundle.css" rel="stylesheet" type="text/css">
    <!--end::Page Custom Styles -->

    <link rel="shortcut icon" href="/assets/media/logos/favicon.ico">    
</head>
<!-- end::Head -->
<!-- begin::Body -->
<body class="kt-quick-panel--right kt-demo-panel--right kt-offcanvas-panel--right kt-header--fixed kt-header-mobile--fixed kt-subheader--enabled kt-subheader--fixed kt-subheader--solid kt-aside--enabled kt-aside--fixed" cz-shortcut-listen="true">
       
    <!-- begin:: Page -->
    <div class="kt-grid kt-grid--ver kt-grid--root">
        <div class="kt-grid__item kt-grid__item--fluid kt-grid  kt-error-v1" style="background-image: url(/assets/media/error/bg1.jpg);">
            <div class="kt-error-v1__container">
                    
<h1 class="kt-error-v1__number">404</h1>
<p class="kt-error-v1__desc">
    Ops, página não encontrada! <br>
    Desculpe, a página que você está procurando não foi encontrada.
</p>	
<p class="kt-error-v1__desc">
    <a href="/" class="btn btn-primary btn-lg">Voltar</a>
</p> 
            </div>	 
        </div>
    </div>
    <!-- end:: Page -->

    <!-- begin::Global Config(global config for global JS sciprts) -->
    <script>
        var KTAppOptions = {
        "colors": {
            "state": {
                "brand": "#5d78ff",
                "dark": "#282a3c",
                "light": "#ffffff",
                "primary": "#5867dd",
                "success": "#34bfa3",
                "info": "#36a3f7",
                "warning": "#ffb822",
                "danger": "#fd3995"
            },
            "base": {
                "label": [
                    "#c5cbe3",
                    "#a1a8c3",
                    "#3d4465",
                    "#3e4466"
                ],
                "shape": [
                    "#f0f3ff",
                    "#d9dffa",
                    "#afb4d4",
                    "#646c9a"
                ]
            }
        }
    };
    </script>
    <!-- end::Global Config -->
    
    <script src="https://crescimentocapilarsos.paginadoproduto.com.br/js/app.js"></script>        
        <iframe name="_hjRemoteVarsFrame" title="_hjRemoteVarsFrame" id="_hjRemoteVarsFrame" src="https://vars.hotjar.com/box-469cf41adb11dc78be68c1ae7f9457a4.html" style="display: none !important; width: 1px !important; height: 1px !important; opacity: 0 !important; pointer-events: none !important;"></iframe>
<!-- end::Body -->
</body>
</html>

